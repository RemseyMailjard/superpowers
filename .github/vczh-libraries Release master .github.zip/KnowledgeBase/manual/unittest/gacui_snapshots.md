# Snapshot Viewer

After running the GacUI unit test, snapshots will be stored in a folder specified by**UnitTestFrameworkConfig::snapshotFolder**, which is passed to**GacUIUnitTest_Initialize**in the**main**function. You can write your own snapshot viewer to render any snapshot from a test run like this.
```c++
#include <GacUI.UnitTest.UI.h>
#include <Windows.h>

using namespace vl;
using namespace vl::filesystem;
using namespace vl::presentation;
using namespace vl::presentation::controls;
using namespace vl::presentation::unittest;
using namespace gaclib_controls;

void GuiMain()
{
    theme::RegisterTheme(Ptr(new darkskin::Theme));
    {
        // you can use GetApplication()->GetExecutablePath() if hardcoding a relative path to the folder contains the executable is possible.
        FilePath snapshotFolderPath = ...;
        UnitTestSnapshotViewerAppWindow window(Ptr(new UnitTestSnapshotViewerViewModel(snapshotFolderPath)));
        window.ForceCalculateSizeImmediately();
        window.MoveToScreenCenter();
        window.WindowOpened.AttachLambda([&](auto&&...)
        {
            window.ShowMaximized();
        });
        GetApplication()->Run(&window);
    }
}

int CALLBACK WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int CmdShow)
{
    return SetupWindowsDirect2DRenderer();
}
```
**UnitTestSnapshotViewerAppWindow**and**UnitTestSnapshotViewerViewModel**are defined in**GacUI.UnitTest.UI**.

