# Controls

Controls are interfaces with predefined functionalities. A control doesn't care about what it looks like, control templates handle all of these.

There are also**virtual controls**. A virtual control is a predefined configuration to an existing control, which changes some properties of that control with a different control template.

**CheckBox**and**RadioButton**are typical virtual controls. They do not exist in C++, they are just**SelectableButton**with different control templates. They also have behavior differences, for example, when you click a**CheckBox**, it switches between selected and unselected, but when you click a**RadioButton**, it always try to become selected.

GacUI offers a set of predefined controls:
- `empty list item`
  **Basic Controls:** - **Label**: Displays interactive texts. - **Button**: Reacts to mouse input. - **DatePicker**and**DateComboBox**: Displays and choosing date. - **SelectableButton**: Button with a select mark. This control is not intended to be used directly, you are supposed to use the following virtual controls: - **CheckBox**: A selectable button that represents individual selection. - **RadioButton**: A selectable button that represents a selection among different choices. - **Scroll**: Displays editable position information. This control is not intended to be used directly, you are supposed to use the following virtual controls: - **ProgressBar**: Display readonly progress information. - **HScroll**,**VScroll**,**HTracker**,**VTracker**: Displays editable position information for different directions and purposes.
- `empty list item`
  **Container Controls:** - **Tab**and**TabPage**: Organizes controls into multiple pages, only one page can be displayed at a time. - **ScrollContainer**: Displays scroll bars when content inside it exceeds the visible boundary.
- `empty list item`
  **Editor Controls:** - **SinglelineTextBox**and**MultilineTextBox**: Displays editable plain text. - **DocumentLabel**and**DocumentViewer**: Displays editable text or rich document, allowing compositions and controls to be embedded into a document.
- `empty list item`
  **List Controls:** - **TextList**,**ListView**,**TreeView**: Organize data into some predefined list structure. - **BindableTextList**,**BindableListView**,**BindableTreeView**: Bindable version of list controls, which change content automatically when data in a collection is changed. - **BindableDataGrid**: Organizes data into a table, in which different cells could have different views and editors. - **ComboBox**: A control with a dropdown that containing a list control.
- `empty list item`
  **Toolstrip Controls:** - **ToolstripMenu**: A popup menu. - **ToolstripMenuBar**: A menu bar for first level menu items. - **ToolstripToolBar**: A container for toolstrip buttons. - **ToolstripToolBarInMenu**: A container for toolstrip buttons, when the toolstrip is in a menu. - **ToolstripGroupContainer**and**ToolstripGroup**: Organize menu items or toolstrip buttons into different groups in dropdown menus or toolstrip toolbars. - **ToolstripButton**: A button with icon in**ToolstripToolBar**. - Virtual**ToolstripButton**controls for menus: - **MenuBarButton**: Menu item in**ToolstripMenuBar**. - **MenuItemButton**: Menu item in**ToolstripMenu**. - **MenuSplitter**: A splitter between menu buttons. - Virtual**ToolstripButton**controls for toolbars: - **ToolstripDropdownButton**: A button in**ToolstripToolBar**, clicking it opens a dropdown menu. - **ToolstripSplitButton**: A button in**ToolstripToolBar**, splitted into a button and a small dropdown button. - **ToolstripSplitter**: A splitter between toolstrip buttons. - **ToolstripSplitterInMenu**: A splitter between toolstrip buttons, when the toolstrip is in a menu.
- `empty list item`
  **Ribbon Controls:** - **RibbonTab**and**RibbonTabPage**: The first level container for ribbon controls, organizs ribbon controls into different pages. - **RibbonGroup**: The second level container for ribbon controls, when the space is not enough for the whole group, it becomes a super large dropdown button. - **RibbonIconLabel**: Displays icon and text before another control. - **RibbonSmallIconLabel**: A virtual**RibbonIconLabel**control that looks smaller. - Virtual**ToolstripButton**controls for ribbon: - **RibbonSmallButton**,**RibbonSmallDropdownButton**and**RibbonSmallSplitButton**: Toolstrip toolbar buttons that display not only icons but texts. - **RibbonLargeButton**,**RibbonLargeDropdownButton**and**RibbonLargeSplitButton**: Even larger buttons. - **RibbonToolstrip**: Displays toolbars, redistributes buttons in different numbers of toolbars when the space is changing. - **RibbonGallery**: Displays large icons, and when the space is not enough for all icons, they will be in the dropdown menu. - **BindableRibbonGalleryList**: The gallery list in**RibbonGallery**. - **RibbonToolstripMenu**: The dropdown menu in**RibbonGallery**. - **RibbonToolstripHeader**: Group header in**RibbonToolstripMenu**. - **RibbonButtons**: Displays some**ToolstripButton**and**RibbonIconLabel**in order, when the space is not enough, controls will be automatically changed to different outfit including - **ToolstripButton** - **ToolstripDropdownButton** - **ToolstripSplitButton** - **RibbonSmallButton** - **RibbonSmallDropdownButton** - **RibbonSmallSplitButton** - **RibbonLargeButton** - **RibbonLargeDropdownButton** - **RibbonLargeSplitButton** - **RibbonIconLabel** - **RibbonSmallIconLabel**
- `empty list item`
  **Root Controls:** - **CustomControl**: Blank control for customize. - **Window**: The most outer container that interacts with window manager of OS.

## Toolstrip Controls


- Source code:[Tutorial/GacUI_Controls/DocumentEditorToolstrip/UI/ResourceToolstrip.xml](https://github.com/vczh-libraries/Release/blob/master/Tutorial/GacUI_Controls/DocumentEditorToolstrip/UI/ResourceToolstrip.xml)
- ![](https://gaclib.net/doc/gacui/kb_controls_toolstrip.gif)

## Ribbon Controls


- Source code:[Tutorial/GacUI_Controls/DocumentEditorRibbon/UI/ResourceRibbon.xml](https://github.com/vczh-libraries/Release/blob/master/Tutorial/GacUI_Controls/DocumentEditorRibbon/UI/ResourceRibbon.xml)
- ![](https://gaclib.net/doc/gacui/kb_controls_ribbon.gif)

## Code Editor


- Source code:[Tutorial/GacUI_Controls/TextEditor/UI/MainWindow.xml](https://github.com/vczh-libraries/Release/blob/master/Tutorial/GacUI_Controls/TextEditor/UI/MainWindow.xml)
- ![](https://gaclib.net/doc/gacui/kb_controls_textbox.gif)

## DataGrid


- Source code:[Tutorial/GacUI_Controls/DataGrid/UI/Resource.xml](https://github.com/vczh-libraries/Release/blob/master/Tutorial/GacUI_Controls/DataGrid/UI/Resource.xml)
- ![](https://gaclib.net/doc/gacui/kb_controls_datagrid.gif)

