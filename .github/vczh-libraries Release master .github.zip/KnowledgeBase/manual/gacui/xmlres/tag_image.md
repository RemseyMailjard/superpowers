# \<Image\>

[Here](https://github.com/vczh-libraries/Release/blob/master/SampleForDoc/GacUI/XmlRes/kb_xmlres_data/ImagePage.xml)is the sample used in this topic.

**\<Image/\>**works like**\<Text/\>**, but there are a few differences:
- **content="File"**is always required.
- It can be assigned to properties that accept**presentation::INativeImage^**or**presentation::GuiImageData^**.

In GacUI,**GuiImageElement**, menus, toolstrip buttons, ribbon buttons and list items are able to be assigned images.

In the sample, images are stored in a folder in a separated file:
```
<Folder>
  <Image content="File">New.png</Image>
  <Image content="File">NewText.png</Image>
  <Image content="File">NewXml.png</Image>
  <Image content="File">Open.png</Image>
  <Image content="File">Save.png</Image>
  <Image content="File">SaveAs.png</Image>
  <Image content="File">EditCopy.png</Image>
  <Image content="File">EditCut.png</Image>
  <Image content="File">EditDelete.png</Image>
  <Image content="File">EditFind.png</Image>
  <Image content="File">EditPaste.png</Image>
  <Image content="File">EditRedo.png</Image>
  <Image content="File">EditUndo.png</Image>
</Folder>
```


Then a set of**ToolstripCommand**are created, images are assigned to them.
```
<Instance ref.Class="sample::ImagePage">
  <TabPage Text="&lt;Image/&gt;">
    <ToolstripCommand ref.Name="commandFileNewText" Text="Text File" Image-uri="res://MainWindow/ImagePage/Images/NewText.png"/>
    <ToolstripCommand ref.Name="commandFileNewXml" Text="Xml File" Image-uri="res://MainWindow/ImagePage/Images/NewXml.png"/>
    <ToolstripCommand ref.Name="commandFileOpen" Text="Open ..." Image-uri="res://MainWindow/ImagePage/Images/Open.png" ShortcutBuilder="Ctrl+O"/>
    <ToolstripCommand ref.Name="commandFileOpenText" Text="Text File ..." Image-uri="res://MainWindow/ImagePage/Images/NewText.png"/>
    <ToolstripCommand ref.Name="commandFileOpenXml" Text="Xml File ..." Image-uri="res://MainWindow/ImagePage/Images/NewXml.png"/>
    <ToolstripCommand ref.Name="commandFileSave" Text="Save" Image-uri="res://MainWindow/ImagePage/Images/Save.png" ShortcutBuilder="Ctrl+S"/>
    <ToolstripCommand ref.Name="commandFileSaveAs" Text="Save As ..." Image-uri="res://MainWindow/ImagePage/Images/SaveAs.png"/>
    <ToolstripCommand ref.Name="commandFileExit" Text="Exit"/>

    <ToolstripCommand ref.Name="commandEditUndo" Text="Undo" Image-uri="res://MainWindow/ImagePage/Images/EditUndo.png" ShortcutBuilder="Ctrl+Z"/>
    <ToolstripCommand ref.Name="commandEditRedo" Text="Redo" Image-uri="res://MainWindow/ImagePage/Images/EditRedo.png" ShortcutBuilder="Ctrl+Y"/>
    <ToolstripCommand ref.Name="commandEditCut" Text="Cut" Image-uri="res://MainWindow/ImagePage/Images/EditCut.png" ShortcutBuilder="Ctrl+X"/>
    <ToolstripCommand ref.Name="commandEditCopy" Text="Copy" Image-uri="res://MainWindow/ImagePage/Images/EditCopy.png" ShortcutBuilder="Ctrl+C"/>
    <ToolstripCommand ref.Name="commandEditPaste" Text="Paste" Image-uri="res://MainWindow/ImagePage/Images/EditPaste.png" ShortcutBuilder="Ctrl+V"/>
    <ToolstripCommand ref.Name="commandEditDelete" Text="Delete" Image-uri="res://MainWindow/ImagePage/Images/EditDelete.png"/>
    <ToolstripCommand ref.Name="commandEditSelect" Text="Select All" ShortcutBuilder="Ctrl+A"/>
    <ToolstripCommand ref.Name="commandEditFind" Text="Find ..." Image-uri="res://MainWindow/ImagePage/Images/EditFind.png" ShortcutBuilder="Ctrl+F"/>

    ...
  </TabPage>
</Instance>
```
A**ToolstripCommand**can be assigned to multiple menu items, toolstrip buttons and ribbon buttons. In this way, these controls share the same image, text, shortcut. If a toolstrip command is disabled, associated controls will all be disabled.

Here is how it looks like:


- Source code:[kb_xmlres_data](https://github.com/vczh-libraries/Release/blob/master/SampleForDoc/GacUI/XmlRes/kb_xmlres_data/ImagePage.xml)
- ![](https://gaclib.net/doc/gacui/kb_xmlres_tag_image.gif)

