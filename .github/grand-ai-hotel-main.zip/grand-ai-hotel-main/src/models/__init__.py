"""Model definitions and training."""
